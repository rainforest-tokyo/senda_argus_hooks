from __future__ import annotations

import contextlib
import time
from collections.abc import Callable
from typing import Any

from senda_argus_hooks.core.hashing import sha256_value
from senda_argus_hooks.core.identity import (
    data_source_hash,
    derive_mcp_profile_id,
    derive_purpose_id,
    mcp_data_source_profile,
    normalize_url,
    resolve_mcp_server_name,
)
from senda_argus_hooks.core.instruction_files import classify_instruction_write
from senda_argus_hooks.core.resource_access import (
    classify_read_resource,
    classify_resource_access,
)
from senda_argus_hooks.core.runtime import emit_event, get_config

from .base import BaseInstrumentor, audit_guard


class MCPPythonInstrumentor(BaseInstrumentor):
    name = "mcp_python"

    def __init__(self):
        self._patches: list[tuple[Any, str, Callable]] = []

    def instrument(self) -> bool:
        candidates = []
        with contextlib.suppress(Exception):
            from mcp import ClientSession
            candidates.append((ClientSession, "call_tool", "call_tool"))
            candidates.append((ClientSession, "read_resource", "read_resource"))
            candidates.append((ClientSession, "list_tools", "list_tools"))
            candidates.append((ClientSession, "list_resources", "list_resources"))
        patched = False
        for cls, method_name, op in candidates:
            original = getattr(cls, method_name, None)
            if original is None or hasattr(original, "__senda_patched__"):
                continue
            wrapped = self._wrap(original, op)
            wrapped.__senda_patched__ = True
            setattr(cls, method_name, wrapped)
            self._patches.append((cls, method_name, original))
            patched = True
        return patched

    def _wrap(self, original: Callable, operation: str) -> Callable:
        def sync_wrapper(obj, *args, **kwargs):
            result = original(obj, *args, **kwargs)
            if hasattr(result, "__await__"):
                async def awaited():
                    return await self._observe_async_call(original_result=result, operation=operation, obj=obj, args=args, kwargs=kwargs)
                return awaited()
            return result
        return sync_wrapper

    async def _observe_async_call(self, *, original_result, operation: str, obj, args, kwargs):
        cfg = get_config()
        started = time.perf_counter()
        meta = _mcp_metadata(obj, operation, args, kwargs)
        purpose_id = meta["purpose_id"]
        if operation == "call_tool":
            emit_event(
                "mcp.tool_call.requested",
                source={"component": "instrumentor", "sdk": "mcp_python", "operation": operation},
                data={"mcp": meta},
                status="start",
                purpose_id=purpose_id,
            )
        try:
            response = await original_result
        except Exception as exc:
            latency_ms = int((time.perf_counter() - started) * 1000)
            emit_event(
                "mcp.tool_call.failed" if operation == "call_tool" else f"mcp.{operation}.failed",
                source={"component": "instrumentor", "sdk": "mcp_python", "operation": operation},
                data={"mcp": meta},
                status="error",
                latency_ms=latency_ms,
                error={"type": exc.__class__.__name__, "message": str(exc)},
                purpose_id=purpose_id,
            )
            raise

        # 観測の後処理は本来の呼び出しから隔離する。ここで失敗しても応答は返す。
        with audit_guard(operation):
            latency_ms = int((time.perf_counter() - started) * 1000)
            result_payload = _safe_response(response)
            data = {"mcp": {**meta}}
            if cfg.capture_result:
                data["mcp"]["result"] = result_payload
            data["mcp"]["result_hash"] = sha256_value(result_payload)
            emit_event(
                "mcp.tool_call.completed" if operation == "call_tool" else f"mcp.{operation}.completed",
                source={"component": "instrumentor", "sdk": "mcp_python", "operation": operation},
                data=data,
                status="success",
                latency_ms=latency_ms,
                purpose_id=purpose_id,
            )
        return response

    def uninstrument(self) -> bool:
        for cls, method_name, original in self._patches:
            setattr(cls, method_name, original)
        self._patches = []
        return True


def _extract_arguments(operation: str, args, kwargs) -> dict[str, Any]:
    if operation == "call_tool":
        return {"tool": args[0] if args else kwargs.get("name"), "arguments": args[1] if len(args) > 1 else kwargs.get("arguments")}
    return {"args": args, "kwargs": kwargs}


def _mcp_metadata(obj, operation: str, args, kwargs) -> dict[str, Any]:
    cfg = get_config()
    arguments = _extract_arguments(operation, args, kwargs)
    tool_name = arguments.get("tool")
    server_name = resolve_mcp_server_name(obj)
    server_url = getattr(obj, "url", None) or getattr(obj, "base_url", None) or getattr(obj, "server_url", None)
    capability = kwargs.get("capability") or getattr(obj, "capability", None)
    args_hash = sha256_value(arguments)
    mcp_profile_id = derive_mcp_profile_id(mcp_server_name=server_name, mcp_server_url=server_url)
    purpose_profile = mcp_data_source_profile(mcp_server_name=server_name, mcp_server_url=server_url, tool_name=str(tool_name), capability=capability)
    purpose_id = derive_purpose_id(mcp_server_name=server_name, mcp_server_url=server_url, tool_name=str(tool_name), capability=capability)
    source_hash = data_source_hash(purpose_profile)
    meta = {
        "operation": operation,
        "server": server_name,
        "server_url": normalize_url(str(server_url)) if server_url else None,
        "tool": tool_name,
        "capability": capability,
        "mcp_profile_id": mcp_profile_id,
        "purpose_id": purpose_id,
        "purpose_source": "mcp_data_source_hash",
        "purpose_profile": purpose_profile,
        "data_source_hash": source_hash,
        # 呼び出しを包んだ外側の辞書のダイジェスト。相関の追跡に使う既存の項目であり、
        # 判定が読む書き込みの内容のダイジェストは分類器が資源の引数から作って上書きする。
        "arguments_hash": args_hash,
    }
    # 提供元の識別には、表示名だけでなく正規化した URL も含める。表示名は重複しうるし、
    # 取得できないときは同じ既定値へ落ちる。名前だけで括ると、別の提供元の同名の資源が
    # 同じ鍵に集まり、無関係な読み書きが往復に見える。
    resource_scope = mcp_profile_id
    if operation == "call_tool":
        # 同じ資源への読み取りと書き込みを 1 つの鍵で結び付ける。data_source_hash はツール名を
        # 含むため、同じ資源でも読み取りと書き込みで別の値になり、往復を追う鍵にならない。
        # 名前そのものは載せない。判定に要るのは同一性だけで、名前を運ぶと受け取り側の権威記録に残る。
        meta.update(classify_resource_access(arguments.get("arguments"), server=resource_scope))
        # 指示ファイルへの書き込みは、次のエージェントへ払い出しが渡る経路になる。突合に使う
        # ダイジェストだけを載せる。本文は載せない。分類の可否は受け取り側が名前から判定し直すため、
        # ここでの分類は候補の提示にとどまる。
        written = classify_instruction_write(arguments.get("arguments"))
        if written:
            meta.update(written)
    elif operation == "read_resource":
        # 資源の直接読み取りは引数の形が違い、位置引数か uri に資源が直接入る。ここを通さないと
        # 同じ資源への読み取りがツール呼び出しの書き込みと結び付かず、往復として現れない。
        # 指示ファイルの分類は本文にあたる引数を要するため、この経路では該当しない。
        #
        # 分岐は当該の操作に限る。一覧を取る操作も引数を位置で受けるため、まとめて通すと
        # 継続位置の値を資源と取り違え、存在しない鍵を読み取りとして作ってしまう。
        meta.update(
            classify_read_resource(arguments.get("args"), arguments.get("kwargs"), server=resource_scope)
        )
    if cfg.capture_arguments:
        meta["arguments"] = {**arguments, "purpose_id": purpose_id, "data_source_hash": source_hash}
    return meta


def _safe_response(response: Any) -> Any:
    for attr in ("model_dump", "dict"):
        if hasattr(response, attr):
            with contextlib.suppress(Exception):
                return getattr(response, attr)()
    return str(response)
