from __future__ import annotations

import atexit
import contextlib
import json
import logging
import sys
import queue
import threading
import time
import urllib.error
import urllib.request
from typing import Any

from .base import BaseExporter

# 送出は境界付きキューと単一のワーカースレッドで行う。バッチごとにスレッドを起こすと、
# 既定バッチサイズが 1 のため送信先が遅いとスレッドが無制限に積み上がってメモリや
# スレッド上限を圧迫し、start() が失敗すると同期送信に落ちてホスト経路を止める。
# 単一ワーカーで FIFO を保ち、shutdown / atexit で積み残しを送り切る。
_SEND_QUEUE_MAX = 1000
_DRAIN_TIMEOUT = 3.0
_SHUTDOWN = object()
_DROP_WARN_INTERVAL = 60.0

_logger = logging.getLogger("senda_argus_hooks.exporters.argus")


class ArgusExporter(BaseExporter):
    """Argus 検知エンジンの /v1/agent-runs/ingest エンドポイントへイベントを送信する。

    設定例:
        {
            "type": "argus",
            "endpoint": "http://localhost:8000",
            "api_key": "your-api-key",
            "run_id": "optional-fixed-run-id",
            "timeout": 10,
            "log_payload": false
        }

    endpoint + "/v1/agent-runs/ingest" に POST する。
    送信エラーは無視してパイプラインを継続する (fire-and-forget)。

    指示ファイルの伝播の検知を効かせるには、api_key に収集用の鍵を設定する。受け取り側は、通常の
    テナントの鍵で届いた記録から書き込みと指示の証拠を採らない。収集用の鍵は発行時に並べた agent_id
    の記録に限って証拠を信頼させるため、この処理で動くエージェントの agent_id を並べて発行する。
    """

    def __init__(self, config: dict[str, Any]) -> None:
        endpoint = config.get("endpoint", "http://localhost:8000").rstrip("/")
        self._url = endpoint + "/v1/agent-runs/ingest"
        self._api_key: str = config.get("api_key", "")
        self._run_id: str | None = config.get("run_id")
        self._timeout: int = int(config.get("timeout", 10))
        self._log_http: bool = bool(config.get("log_http", False))
        self._log_payload = config.get("log_payload") is True
        self._queue: queue.Queue = queue.Queue(maxsize=_SEND_QUEUE_MAX)
        self._worker: threading.Thread | None = None
        self._worker_lock = threading.Lock()
        self._atexit_registered = False
        self._drop_lock = threading.Lock()
        self._dropped_events_count = 0
        self._last_drop_warn = 0.0

    def _record_drop(self, count: int) -> None:
        """送出キュー満杯で捨てたイベント数を計数し、警告を一定間隔に間引いてログに残す。

        count は捨てたバッチに含まれるイベント数。バッチ単位でなくイベント単位で数えるため、
        バッチサイズが 1 を超えても欠落数を正しく表す。障害で連続 drop するとき export ごとに
        同期ログを書くとログが氾濫し呼び出し経路を塞ぐため、警告は間引いて非ブロッキング性を保つ。
        沈黙 drop で欠落を見失わない。
        """
        now = time.monotonic()
        with self._drop_lock:
            self._dropped_events_count += count
            total = self._dropped_events_count
            should_warn = (now - self._last_drop_warn) >= _DROP_WARN_INTERVAL
            if should_warn:
                self._last_drop_warn = now
        if should_warn:
            _logger.warning("Argus 送出キューが満杯のためイベントを破棄しました。累計 %d 件", total)

    def dropped_events(self) -> int:
        """送出キュー満杯で捨てたバッチの累計を返す。"""
        with self._drop_lock:
            return self._dropped_events_count

    def _http_log(self, message: str) -> None:
        """Write transport-only diagnostics to stderr when explicitly enabled.

        The message never includes request headers, API keys, or event bodies.  This
        makes the output safe to surface in Agent Studio's Docker Logs panel while
        keeping normal production runtimes quiet unless SENDA_ARGUS_HTTP_LOG=true.
        """
        if not self._log_http:
            return
        print(f"[senda-argus-http] {message}", file=sys.stderr, flush=True)

    @staticmethod
    def _event_count(payload: bytes) -> int | None:
        try:
            body = json.loads(payload.decode("utf-8"))
            events = body.get("events") if isinstance(body, dict) else None
            return len(events) if isinstance(events, list) else None
        except Exception:
            return None

    def _send(self, payload: bytes, headers: dict[str, str]) -> None:
        req = urllib.request.Request(
            self._url, data=payload, method="POST", headers=headers
        )
        count = self._event_count(payload) if self._log_http else None
        suffix = f" events={count}" if count is not None else ""
        self._http_log(f"POST {self._url}{suffix} bytes={len(payload)}")
        if self._log_payload:
            with contextlib.suppress(OSError, ValueError):
                print(f"[senda-argus-http] payload={payload.decode('utf-8')}", file=sys.stderr, flush=True)
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as response:
                status = getattr(response, "status", None) or response.getcode()
            self._http_log(f"POST completed status={status} url={self._url}{suffix}")
        except urllib.error.HTTPError as exc:
            self._http_log(f"POST failed status={exc.code} url={self._url}{suffix} error={exc.reason}")
        except (urllib.error.URLError, OSError) as exc:
            reason = getattr(exc, "reason", exc)
            self._http_log(f"POST failed url={self._url}{suffix} error={reason}")

    def _worker_loop(self) -> None:
        while True:
            item = self._queue.get()
            try:
                if item is _SHUTDOWN:
                    return
                payload, headers = item
                self._send(payload, headers)
            finally:
                self._queue.task_done()

    def _ensure_worker(self) -> None:
        if self._worker is not None and self._worker.is_alive():
            return
        with self._worker_lock:
            if self._worker is not None and self._worker.is_alive():
                return
            self._worker = threading.Thread(target=self._worker_loop, daemon=True)
            self._worker.start()
            if not self._atexit_registered:
                atexit.register(self.shutdown)
                self._atexit_registered = True

    def export(self, events: list[dict[str, Any]]) -> None:
        if not events:
            return
        if self._run_id:
            events = [dict(ev, run_id=ev.get("run_id") or self._run_id) for ev in events]
        payload = json.dumps({"events": events}, ensure_ascii=False, default=str).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["X-API-Key"] = self._api_key
        # 送信をキューへ積み、単一ワーカーが FIFO 順にホスト経路の外で送る。キューが
        # 満杯なら捨てて呼び出し側を待たせない。ワーカーは 1 本に限定する。
        self._ensure_worker()
        try:
            self._queue.put_nowait((payload, headers))
        except queue.Full:
            self._record_drop(len(events))

    def shutdown(self) -> None:
        # 終了時に積み残したバッチを送り切る。daemon ワーカーは通常終了で待たれないため、
        # EventBus.shutdown と atexit の双方からここを通して drain する。
        super().shutdown()
        worker = self._worker
        if worker is None or not worker.is_alive():
            return
        with contextlib.suppress(queue.Full):
            self._queue.put_nowait(_SHUTDOWN)
        worker.join(timeout=_DRAIN_TIMEOUT)
